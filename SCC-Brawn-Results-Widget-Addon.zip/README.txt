SCC Rainmeter Widgets — add Brawn 2026 Results as a fourth widget

1. Keep your current SCC-Widgets installation. Do not delete SOP, MySQL, or Timer folders.
2. Copy SCC-Widgets/BrawnResults into Documents/Rainmeter/Skins/SCC-Widgets/.
3. Right-click Rainmeter > Refresh all.
4. Manage Rainmeter > SCC-Widgets > BrawnResults > SCC-Brawn-Results.ini > Load.
5. Click Open Qualifiers, Citizens, or Open Finals. Each opens the respective section of the SCC SOP Hub in your browser.

This skin is independent, draggable, and unloadable. Edit Scale or PanelAlpha in the INI to adjust size/transparency. It does not retrieve or cache scores and does not modify the scoring system. It uses your published results page as its destination.
