@echo off
start "" powershell.exe -NoLogo -NoProfile -NoExit -ExecutionPolicy Bypass -File "%~dp0Launch-Drawer-Counter.ps1"
