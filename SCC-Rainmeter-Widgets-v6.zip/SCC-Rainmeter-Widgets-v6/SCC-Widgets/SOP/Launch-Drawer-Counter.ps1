# Edit this path after confirming the file location on SCC Computer 1.
# %USERPROFILE% works for whoever is signed in; the file must be on this PC.
$DrawerScript = '%USERPROFILE%\Desktop\TS\PowerShell scripts\DrawerCounter.ps1'

$path = [Environment]::ExpandEnvironmentVariables($DrawerScript)
Write-Host 'SCC Drawer Counter' -ForegroundColor Cyan
if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
    Write-Host 'Drawer Counter script not found.' -ForegroundColor Yellow
    Write-Host ('Expected: ' + $path)
    Write-Host 'Edit DrawerScript in Launch-Drawer-Counter.ps1 with the correct full file path.'
    return
}
try {
    & $path
} catch {
    Write-Host ('Could not run the script: ' + $_.Exception.Message) -ForegroundColor Red
}
