SCC RAINMETER WIDGETS v5
%USERPROFILE%\Documents\Rainmeter\Skins

----------------------------------------

Fixes: MySQL checker runs from the same folder as its INI. Output is limited to short status text.
The SOP and MySQL skins can run at the same time.

INSTALL
1. Unload the old SCC skins in Rainmeter.
2. Delete old copies of SCC-Widgets, then copy the SCC-Widgets folder here:
   Documents\Rainmeter\Skins\SCC-Widgets
   Do NOT put SCC-Widgets inside another Rainmeter skin folder.
3. Rainmeter > Manage > Refresh all.
4. Load MySQL\SCC-MySQL-Status.ini and SOP\SCC-SOP-Hub.ini independently.

MYSQL SETUP
Edit MySQL\SCC-MySQL-Status.ini and set MainComputer to the IP/hostname of the SCC main register computer.
Leave SET_MAIN_COMPUTER_IP in place on a test PC to display NOT CONFIGURED rather than a false failure.
MySQL status tests whether TCP port 3306 is reachable, not a database login.

SETTINGS
Edit Scale=1.0 and PanelAlpha=242 in either INI, then Refresh skin.
Drag each widget by its background. Right-click > Settings > Draggable must be on.

TEST
From the MySQL folder, run in PowerShell:
  .\Check-SCC-MySQL.ps1 -Target SET_MAIN_COMPUTER_IP -Port 3306
Expected: NOT CONFIGURED

Status meanings:
CONNECTED = database port reachable
DISCONNECTED = configured server cannot be reached
NOT CONFIGURED = no host address set on this computer
CHECK ERROR = connection test did not run correctly

DRAWER COUNTER BUTTON (SOP WIDGET)
The RUN DRAWER COUNTER button opens PowerShell and runs a local .ps1 file.
It does not launch a script on another PC remotely.
On SCC Computer 1, edit SOP\Launch-Drawer-Counter.ps1:
  $DrawerScript = '%USERPROFILE%\Desktop\TS\PowerShell scripts\DrawerCounter.ps1'
Replace the path with the actual .ps1 location and filename.
If the file is missing, the PowerShell window displays the path to fix.
The HOW TO USE link opens the Drawer Counter SOP instructions.
No need to change the SOP .ini when updating the script path.

SCC MYSQL DEFAULTS (v6)
Computer 1 host: SCC_PC (hostname; dynamic IP)
MySQL TCP port: 3306
Database: springsclimbingcenter (not used by TCP status check)
No MySQL password is needed or stored.
On SCC Computer 2, run: Test-NetConnection SCC_PC -Port 3306
If hostname resolution fails, verify Computer 1 hostname on-site.
The Drawer Counter script path still needs to be confirmed on Computer 1.
