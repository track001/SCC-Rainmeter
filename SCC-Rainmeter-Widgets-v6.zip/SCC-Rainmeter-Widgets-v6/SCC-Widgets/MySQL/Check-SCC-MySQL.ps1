param(
    [string]$Target = 'SCC_PC',
    [int]$Port = 3306
)

# TCP check only. Does not verify a database login.
try {
    if ([string]::IsNullOrWhiteSpace($Target) -or $Target -eq 'SET_MAIN_COMPUTER_IP') {
        [Console]::Out.Write('NOT CONFIGURED')
        exit 0
    }
    if ($Port -lt 1 -or $Port -gt 65535) {
        [Console]::Out.Write('CHECK ERROR')
        exit 0
    }
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $result = $client.BeginConnect($Target, $Port, $null, $null)
        if (-not $result.AsyncWaitHandle.WaitOne(2500, $false)) {
            [Console]::Out.Write('DISCONNECTED')
            exit 0
        }
        $client.EndConnect($result)
        [Console]::Out.Write('CONNECTED')
    }
    catch {
        [Console]::Out.Write('DISCONNECTED')
    }
    finally {
        if ($null -ne $result -and $null -ne $result.AsyncWaitHandle) { $result.AsyncWaitHandle.Close() }
        $client.Close()
    }
}
catch {
    [Console]::Out.Write('CHECK ERROR')
}
